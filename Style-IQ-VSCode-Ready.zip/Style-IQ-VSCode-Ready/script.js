const $ = (selector, scope = document) => scope.querySelector(selector);
const $$ = (selector, scope = document) => [...scope.querySelectorAll(selector)];

const modal = $("#profileModal");
const dialog = $(".profile-modal", modal);
const steps = $$(".form-step");
const progressFill = $("#progressFill");
const stepLabel = $("#stepLabel");
const progressPercent = $("#progressPercent");
const nextBtn = $("#nextStep");
const backBtn = $("#backStep");
const photoInput = $("#photoInput");
const uploadZone = $("#uploadZone");
const uploadPrompt = $("#uploadPrompt");
const previewWrap = $("#previewWrap");
const photoPreview = $("#photoPreview");
const toast = $("#toast");

let currentStep = 0;
let uploadedImageUrl = null;
let profile = {};
let returnFocusTo = null;
let toastTimer = null;
let analysisTimers = [];

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2800);
}

function openModal() {
  $("#analysisScreen").classList.remove("show");
  $("#analysisScreen").setAttribute("aria-hidden", "true");
  $("#resultsPage").classList.remove("show");
  $("#resultsPage").setAttribute("aria-hidden", "true");
  returnFocusTo = document.activeElement instanceof HTMLElement ? document.activeElement : null;
  modal.classList.add("open");
  modal.setAttribute("aria-hidden", "false");
  document.body.classList.add("modal-open");
  setStep(0);
  requestAnimationFrame(() => $("#height").focus());
}

function closeModal({ restoreFocus = true } = {}) {
  modal.classList.remove("open");
  modal.setAttribute("aria-hidden", "true");
  document.body.classList.remove("modal-open");
  if (restoreFocus && returnFocusTo?.isConnected) returnFocusTo.focus();
}

$$('[data-start]').forEach(button => button.addEventListener("click", openModal));
$("#closeModal").addEventListener("click", () => closeModal());
modal.addEventListener("click", event => {
  if (event.target === modal) closeModal();
});

document.addEventListener("keydown", event => {
  if (!modal.classList.contains("open")) return;
  if (event.key === "Escape") {
    event.preventDefault();
    closeModal();
    return;
  }
  if (event.key !== "Tab") return;
  const focusable = $$('button:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled]), a[href], [tabindex]:not([tabindex="-1"])', dialog)
    .filter(element => element.getClientRects().length > 0);
  if (!focusable.length) {
    event.preventDefault();
    dialog.focus();
    return;
  }
  const first = focusable[0];
  const last = focusable[focusable.length - 1];
  if (event.shiftKey && document.activeElement === first) {
    event.preventDefault();
    last.focus();
  } else if (!event.shiftKey && document.activeElement === last) {
    event.preventDefault();
    first.focus();
  }
});

function setStep(index) {
  currentStep = index;
  steps.forEach((step, i) => {
    const active = i === index;
    step.classList.toggle("active", active);
    step.setAttribute("aria-hidden", String(!active));
  });
  const percent = ((index + 1) / steps.length) * 100;
  progressFill.style.width = `${percent}%`;
  progressFill.parentElement.setAttribute("aria-valuenow", String(Math.round(percent)));
  stepLabel.textContent = `STEP ${String(index + 1).padStart(2, "0")} OF 04`;
  progressPercent.textContent = `${percent}%`;
  backBtn.disabled = index === 0;
  nextBtn.innerHTML = index === steps.length - 1 ? 'View demo results <span>↗</span>' : 'Continue <span>→</span>';
  requestAnimationFrame(() => $("h2", steps[index])?.focus());
}

function validateNumericField(id, min, max, label, { required = false, integer = false } = {}) {
  const input = document.getElementById(id);
  let error = input.closest(".field").querySelector(".error");
  if (!error) {
    error = document.createElement("small");
    error.className = "error";
    input.closest(".field").append(error);
  }
  const raw = input.value.trim();
  const value = raw === "" ? null : Number(raw);
  let message = "";
  if (value === null && required) message = `${label} is required.`;
  else if (value !== null && (!Number.isFinite(value) || value < min || value > max)) message = `${label} must be between ${min} and ${max}.`;
  else if (value !== null && integer && !Number.isInteger(value)) message = `${label} must be a whole number.`;
  error.textContent = message;
  input.setAttribute("aria-invalid", String(Boolean(message)));
  if (message) input.focus();
  return !message;
}

function validateStep() {
  if (currentStep === 0) {
    const heightOk = validateNumericField("height", 100, 230, "Height", { required: true, integer: true });
    if (!heightOk) return false;
    const weightOk = validateNumericField("weight", 25, 250, "Weight", { required: true });
    if (!weightOk) return false;
    const age = $("#age").value.trim();
    if (age && !validateNumericField("age", 13, 100, "Age", { integer: true })) return false;
  }
  if (currentStep === 1 && !$('input[name="bodyType"]:checked')) {
    showToast("Choose a body-shape description or select Not sure.");
    return false;
  }
  if (currentStep === 2) {
    for (const [id, min, max, label] of [["chest", 40, 180, "Chest / bust"], ["waist", 40, 180, "Waist"], ["hips", 40, 200, "Hips"]]) {
      const value = document.getElementById(id).value.trim();
      if (value && !validateNumericField(id, min, max, label)) return false;
    }
  }
  return true;
}

function collectProfile() {
  const value = id => document.getElementById(id).value.trim();
  profile = {
    height: value("height"), weight: value("weight"), age: value("age"),
    gender: value("gender"), bodyType: $('input[name="bodyType"]:checked')?.value || "Not sure",
    chest: value("chest"), waist: value("waist"), hips: value("hips")
  };
}

$("#styleForm").addEventListener("submit", event => event.preventDefault());

["height", "weight", "age", "chest", "waist", "hips"].forEach(id => {
  const input = document.getElementById(id);
  input.addEventListener("input", () => {
    const error = input.closest(".field")?.querySelector(".error");
    if (error) error.textContent = "";
    input.removeAttribute("aria-invalid");
  });
});

nextBtn.addEventListener("click", () => {
  if (!validateStep()) return;
  if (currentStep < steps.length - 1) {
    setStep(currentStep + 1);
  } else {
    collectProfile();
    closeModal({ restoreFocus: false });
    runDemoAnalysis();
  }
});
backBtn.addEventListener("click", () => {
  if (currentStep > 0) setStep(currentStep - 1);
});

$$('input[name="bodyType"]').forEach(input => {
  input.addEventListener("change", () => {
    $$(".body-option").forEach(card => card.classList.toggle("selected", $("input", card).checked));
  });
});

// Image upload is local-only in this prototype. No image is sent to a server.
$("#browsePhoto").addEventListener("click", event => {
  event.stopPropagation();
  photoInput.click();
});
uploadZone.addEventListener("click", event => {
  if (event.target.closest("button")) return;
  if (event.target === uploadZone || event.target.closest("#uploadPrompt")) photoInput.click();
});
photoInput.addEventListener("change", () => {
  handleFile(photoInput.files[0]);
});
["dragenter", "dragover"].forEach(type => uploadZone.addEventListener(type, event => {
  event.preventDefault();
  uploadZone.classList.add("dragover");
}));
["dragleave", "drop"].forEach(type => uploadZone.addEventListener(type, event => {
  event.preventDefault();
  uploadZone.classList.remove("dragover");
}));
uploadZone.addEventListener("drop", event => handleFile(event.dataTransfer?.files?.[0]));

function clearUploadedPhoto() {
  if (uploadedImageUrl) URL.revokeObjectURL(uploadedImageUrl);
  uploadedImageUrl = null;
  photoInput.value = "";
  photoPreview.removeAttribute("src");
  previewWrap.classList.add("hidden");
  uploadPrompt.classList.remove("hidden");
}

function handleFile(file) {
  if (!file) return;
  const allowed = ["image/jpeg", "image/png", "image/webp"];
  if (!allowed.includes(file.type)) {
    photoInput.value = "";
    showToast("Please choose a JPG, PNG or WEBP image.");
    return;
  }
  if (file.size > 8 * 1024 * 1024) {
    photoInput.value = "";
    showToast("Your image must be smaller than 8 MB.");
    return;
  }
  if (uploadedImageUrl) URL.revokeObjectURL(uploadedImageUrl);
  uploadedImageUrl = URL.createObjectURL(file);
  photoPreview.src = uploadedImageUrl;
  $("#photoName").textContent = file.name;
  $("#photoSize").textContent = `${(file.size / 1024 / 1024).toFixed(2)} MB`;
  uploadPrompt.classList.add("hidden");
  previewWrap.classList.remove("hidden");
}
$("#removePhoto").addEventListener("click", clearUploadedPhoto);

function runDemoAnalysis() {
  const screen = $("#analysisScreen");
  screen.classList.add("show");
  screen.setAttribute("aria-hidden", "false");
  const bar = $("#loadingBar");
  const label = $("#loadingText");
  const stages = ["Reviewing your profile details...", "Preparing your style profile preview...", "Arranging colour and outfit inspiration...", "Almost ready..."];
  let progress = 0;
  let stage = 0;
  bar.style.width = "0%";
  label.textContent = stages[0];
  const interval = setInterval(() => {
    progress += 25;
    bar.style.width = `${progress}%`;
    stage = Math.min(Math.floor(progress / 25), stages.length - 1);
    label.textContent = stages[stage];
    if (progress >= 100) {
      clearInterval(interval);
      analysisTimers = [];
      const timeout = setTimeout(() => {
        screen.classList.remove("show");
        screen.setAttribute("aria-hidden", "true");
        renderResults();
      }, 450);
      analysisTimers.push(timeout);
    }
  }, 520);
  analysisTimers.push(interval);
}

function renderResults() {
  const results = $("#resultsPage");
  results.classList.add("show");
  results.setAttribute("aria-hidden", "false");
  window.scrollTo({ top: 0, behavior: "auto" });
  const tags = [
    profile.height ? `${profile.height} cm` : null,
    profile.weight ? `${profile.weight} kg` : null,
    profile.bodyType && profile.bodyType !== "Not sure" ? profile.bodyType : null
  ].filter(Boolean);
  $("#summaryTags").innerHTML = tags.map(tag => `<span>${escapeHTML(tag)}</span>`).join("");
  $("#resultName").textContent = profile.age ? `Your style profile · age ${profile.age}` : "Your style profile";
  const resultImg = $("#resultPhoto");
  const placeholder = $("#photoPlaceholder");
  if (uploadedImageUrl) {
    resultImg.src = uploadedImageUrl;
    resultImg.classList.add("visible");
    placeholder.classList.add("hidden");
  } else {
    resultImg.removeAttribute("src");
    resultImg.classList.remove("visible");
    placeholder.classList.remove("hidden");
  }
  const ideas = getStylingIdeas(profile.bodyType);
  $("#stylingIdeas").innerHTML = ideas.map((idea, i) => `
    <article class="idea-card"><span>STYLE IDEA 0${i + 1}</span><h3>${escapeHTML(idea.title)}</h3><p>${escapeHTML(idea.text)}</p></article>
  `).join("");
  updateFavouriteButtons();
}

function getStylingIdeas(type) {
  const base = {
    "Rectangle": [
      { title: "Play with layers", text: "Try layering open shirts, jackets or textured pieces if you enjoy adding dimension." },
      { title: "Explore waist details", text: "Belts, tucked tops and varied rises are options for experimenting with proportions." },
      { title: "Mix garment shapes", text: "Try pairing a relaxed top with a more structured bottom, or vice versa." }
    ],
    "Pear": [
      { title: "Explore shoulder details", text: "Structured shoulders, interesting necklines or statement sleeves can create a different visual balance." },
      { title: "Try varied trouser cuts", text: "Straight-leg, wide-leg and relaxed trousers offer different silhouettes to explore." },
      { title: "Play with colour placement", text: "Experiment with colour, texture and prints wherever you enjoy wearing them." }
    ],
    "Apple": [
      { title: "Try open layers", text: "Open shirts, lightweight jackets and longline layers can create a relaxed vertical line." },
      { title: "Explore different rises", text: "Compare mid-rise and high-rise bottoms to find the comfort and fit you prefer." },
      { title: "Choose comfort first", text: "Soft fabrics and adjustable details can help you feel at ease throughout the day." }
    ],
    "Hourglass": [
      { title: "Explore shaped pieces", text: "Wrap details, defined seams and tailored pieces are options to try if you like a shaped fit." },
      { title: "Try balanced separates", text: "Pair fitted or relaxed tops with bottoms in different cuts to find your preferred balance." },
      { title: "Experiment with belts", text: "A belt can add a styling detail, but it is entirely optional." }
    ],
    "Inverted triangle": [
      { title: "Explore relaxed bottoms", text: "Wide-leg, straight-leg and pleated bottoms offer different ways to play with silhouette." },
      { title: "Try simple upper layers", text: "Minimal tops or softer shoulder details may create a look you enjoy." },
      { title: "Play with proportions", text: "Experiment with different top lengths and bottom shapes to find your preferred combination." }
    ]
  };
  return base[type] || [
    { title: "Start with comfort", text: "Notice which fabrics, fits and shapes feel comfortable for your everyday routine." },
    { title: "Experiment with layers", text: "Try open shirts, light jackets or cardigans to add variety to an outfit." },
    { title: "Make it your own", text: "Use colour, accessories and proportions as creative options—not rules." }
  ];
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" }[char]));
}

function getFavourites() {
  try {
    const parsed = JSON.parse(localStorage.getItem("styleIQFavourites") || "[]");
    return Array.isArray(parsed) ? parsed.filter(item => typeof item === "string") : [];
  } catch {
    return [];
  }
}
function setFavourites(items) {
  try {
    localStorage.setItem("styleIQFavourites", JSON.stringify(items));
    return true;
  } catch {
    showToast("Your browser could not save favourites. Try allowing site storage.");
    return false;
  }
}
function updateFavouriteButtons() {
  const favourites = getFavourites();
  $$(".favourite-btn").forEach(button => {
    const saved = favourites.includes(button.dataset.fav);
    button.classList.toggle("saved", saved);
    button.setAttribute("aria-pressed", String(saved));
    button.textContent = saved ? "♥ Saved" : "♡ Save look";
  });
}

$$(".favourite-btn").forEach(button => button.addEventListener("click", () => {
  const name = button.dataset.fav;
  const favourites = getFavourites();
  const index = favourites.indexOf(name);
  if (index >= 0) favourites.splice(index, 1);
  else favourites.push(name);
  if (!setFavourites(favourites)) return;
  updateFavouriteButtons();
  showToast(index < 0 ? "Look saved to your favourites." : "Removed from favourites.");
}));

$("#editProfile").addEventListener("click", () => {
  $("#resultsPage").classList.remove("show");
  $("#resultsPage").setAttribute("aria-hidden", "true");
  returnFocusTo = $("#editProfile");
  modal.classList.add("open");
  modal.setAttribute("aria-hidden", "false");
  document.body.classList.add("modal-open");
  setStep(0);
  requestAnimationFrame(() => $("#height").focus());
});
$("#startAgain").addEventListener("click", () => {
  resetProject();
});
$("#backHome").addEventListener("click", () => {
  $("#resultsPage").classList.remove("show");
  $("#resultsPage").setAttribute("aria-hidden", "true");
  window.scrollTo({ top: 0, behavior: "smooth" });
});
function resetProject() {
  $("#styleForm").reset();
  $$(".body-option").forEach(card => card.classList.remove("selected"));
  $$(".error").forEach(error => { error.textContent = ""; });
  $$('input[aria-invalid="true"]').forEach(input => input.removeAttribute("aria-invalid"));
  clearUploadedPhoto();
  profile = {};
  openModal();
}
$("#menuToggle").addEventListener("click", () => {
  const nav = $("#mainNav");
  nav.classList.toggle("open");
  $("#menuToggle").setAttribute("aria-expanded", String(nav.classList.contains("open")));
});
$$(".main-nav a").forEach(link => link.addEventListener("click", () => {
  $("#mainNav").classList.remove("open");
  $("#menuToggle").setAttribute("aria-expanded", "false");
}));

window.addEventListener("beforeunload", () => {
  if (uploadedImageUrl) URL.revokeObjectURL(uploadedImageUrl);
});
