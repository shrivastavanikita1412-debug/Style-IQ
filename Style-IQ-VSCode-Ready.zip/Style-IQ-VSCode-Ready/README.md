# Style IQ — VS Code Ready Frontend

A responsive frontend prototype built with HTML, CSS, and vanilla JavaScript.

## Open the project in VS Code (Windows)

1. Download `Style-IQ-VSCode-Ready.zip`.
2. In File Explorer, right-click the ZIP and choose **Extract All**.
3. Open **Visual Studio Code**.
4. Choose **File → Open Folder...** (do not choose Open File).
5. Select the extracted `Style-IQ-VSCode-Ready` folder and click **Select Folder**.
6. In the Explorer sidebar, click `index.html` to view and edit its source code.

The project folder contains ordinary UTF-8 text source files. Do not open the `.zip` itself as a code file.

## Run the website

### Option A — Live Server (recommended)

1. In VS Code, open Extensions with `Ctrl+Shift+X`.
2. Install **Live Server** by Ritwick Dey if it is not already installed.
3. In the Explorer sidebar, right-click `index.html` and choose **Open with Live Server**.
4. Your browser should open the local website, usually at `http://127.0.0.1:5500`.

### Option B — Python local server

Open VS Code's terminal (**Terminal → New Terminal**) with this project folder open, then run:

```powershell
py -m http.server 8000
```

Open `http://localhost:8000` in your browser. Stop the server with `Ctrl+C` in the terminal.

## Project files

- `index.html` — page structure and content
- `style.css` — layout, styling, and responsive rules
- `script.js` — form flow, validation, photo preview, demo results, and favourites
- `.vscode/extensions.json` — recommends Live Server in VS Code

## Prototype limitations

- No backend or AI model is connected.
- Appearance-analysis values are illustrative demonstration content, not validated predictions.
- The photo is previewed locally in the browser; it is not uploaded to a server.
- Outfit photographs and Google Fonts load online, so an internet connection is needed for the complete visual experience.
